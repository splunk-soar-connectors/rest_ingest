# Copyright (c) 2017, The MITRE Corporation. All rights reserved.
# See LICENSE.txt for complete terms.

# STIX TAGS
TAG_STIX_PACKAGE = "{http://stix.mitre.org/stix-1}STIX_Package"
